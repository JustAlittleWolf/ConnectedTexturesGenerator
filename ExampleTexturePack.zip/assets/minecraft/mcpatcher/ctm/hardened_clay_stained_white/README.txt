Put this folder in assets\minecraft\mcpatcher\ctm for it to be working.

You may delete this README.

Please note that you might have to rename hardened_clay_stained_white and it's contents in order for the textures to work properly. If you are not sure how, contact me on discord: JustAlittleWolf#7032